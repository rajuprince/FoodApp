package com.onlinefood.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.onlinefood.model.StoreFoods;

@Repository
public interface StoreFoodsDao extends JpaRepository<StoreFoods, Integer> {

}
